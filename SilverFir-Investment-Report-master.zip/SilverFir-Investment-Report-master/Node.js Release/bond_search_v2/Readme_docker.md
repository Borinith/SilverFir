# How to run in Docker
- install docker and docker-compose
- configure parameters in docker-compose.yml
- run `docker-compose up`
- generated HTML will be in the out/ folder
